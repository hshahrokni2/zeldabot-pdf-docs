# 🔥 GraphRAG BRF Document Processing System

> **Cost-optimized GraphRAG system for BRF document intelligence - Built with 💖 by the BFF team**

A high-precision, fast GraphRAG processing system designed specifically for Swedish BRF (Bostadsrättsförening) documents. Minimizes costs while ensuring stability using only open-source tools, local LLMs via Ollama, and Memgraph Community Edition.

## 🎯 Key Features

- **💰 Ultra Cost-Effective**: ~$50-100/month total (or $0 if run locally)
- **🎯 High Precision**: 50-80% hallucination reduction via GraphRAG
- **⚡ Fast Processing**: Index 100-200 pages in 1-2 hours, queries <5s
- **🔒 Privacy-First**: All processing runs locally, no data leaves your infrastructure
- **📊 BRF-Optimized**: Specialized for Swedish housing cooperative documents

## 🏗️ Architecture

```
[BRF URLs/PDFs] → [Crawl4AI] → [Unstructured.io] → [GraphRAG + Ollama] → [Memgraph] → [Streamlit UI]
```

### Core Components

- **Data Ingestion**: Crawl4AI for web/PDF crawling + Unstructured.io for parsing
- **Knowledge Graph**: Microsoft GraphRAG + Memgraph Community (free Neo4j alternative)  
- **LLM Processing**: Ollama serving Llama3.1 8B + nomic-embed-text embeddings
- **Vector Storage**: FAISS for hybrid retrieval
- **UI**: Streamlit for upload/crawl/query interface
- **Deployment**: Google Cloud spot VMs with auto-shutdown

## 🚀 Quick Start

### Local Development

```bash
# 1. Clone and setup
git clone <your-repo>
cd brf-graphrag-system
./setup-and-push.sh

# 2. Start services  
docker-compose up -d

# 3. Access UI
open http://localhost:8501
```

### Cloud Deployment

```bash
# 1. Setup Google Cloud VM (spot instance, ~70% cost savings)
export PROJECT_ID="your-gcp-project"
./scripts/setup-vm.sh

# 2. Deploy to VM
# (VM will auto-configure via startup script)

# 3. Access via external IP
# Check VM_INFO.txt for URLs
```

## 💰 Cost Breakdown

| Component | Traditional Cost | Our Cost | Savings |
|-----------|------------------|----------|---------|
| LLM API (OpenAI) | $200-500/month | $0 (local) | 100% |
| Graph DB (Neo4j Aura) | $65/month | $0 (Memgraph) | 100% |
| Compute (on-demand) | $300/month | $90/month (spot) | 70% |
| **Total** | **$565-865/month** | **$50-100/month** | **85-90%** |

## 📋 Implementation Progress

### Card 1: ✅ Environment Setup & Cloud Prep (COMPLETED)
- [x] Complete project structure  
- [x] Docker Compose configuration
- [x] GraphRAG settings optimized for Ollama
- [x] Google Cloud VM setup scripts
- [x] Cost optimization with spot instances
- [x] Auto-shutdown for cost savings

### Card 2: 🔄 Crawler & Ingestion Implementation (IN PROGRESS)
- [ ] Crawl4AI integration for BRF websites
- [ ] PDF download and processing pipeline
- [ ] Unstructured.io document parsing
- [ ] Swedish text preprocessing
- [ ] Document type classification

### Upcoming Cards 3-10
- GraphRAG Configuration & KG Build
- Hybrid Retrieval Pipeline  
- UI Development with Streamlit
- Optimization for Speed & Precision
- Deployment to Google Cloud
- Testing & Validation
- Monitoring & Cost Controls
- Documentation & Final Polish

## 🔧 System Requirements

### Minimum Local Setup
- Python 3.12+
- Docker & Docker Compose
- 16GB RAM (32GB recommended)
- 100GB storage

### Recommended Cloud Setup  
- Google Cloud VM: n1-standard-4 + T4 GPU
- Spot instance for 70% cost savings
- Ubuntu 22.04 LTS
- Auto-shutdown after 4h inactivity

## 📊 Performance Targets

- **Indexing Speed**: 100-200 pages in 1-2 hours on GPU
- **Query Speed**: <5 seconds average response time  
- **Precision**: >95% accuracy on BRF-specific questions
- **Hallucinations**: <5% rate via GraphRAG community detection
- **Cost**: Under $100/month for typical usage

## 🛠️ Development

### Project Structure
```
brf-graphrag-system/
├── src/
│   ├── ingestion/     # Crawl4AI + document processing
│   ├── graph/         # GraphRAG + Memgraph integration
│   ├── retrieval/     # Hybrid search (FAISS + Cypher)
│   └── ui/           # Streamlit application
├── config/
│   └── settings.yaml  # GraphRAG configuration
├── scripts/
│   ├── setup-vm.sh   # Google Cloud deployment
│   └── vm-startup.sh # VM initialization
└── docker-compose.yml # Full stack orchestration
```

### Running Tests
```bash
source .venv/bin/activate
pytest tests/ -v
```

### Code Quality
```bash
# Linting
pylint src/

# Type checking  
mypy src/

# Formatting
black src/
```

## 🎯 BRF Document Types Supported

- **Årsredovisningar** (Annual Reports)
- **Energideklarationer** (Energy Declarations)  
- **Styrelseprotokoll** (Board Meeting Minutes)
- **Ekonomiska rapporter** (Financial Reports)
- **Underhållsplaner** (Maintenance Plans)

## 🌟 Key Optimizations

### Cost Optimizations
- Local Llama3.1 8B model (no API costs)
- Memgraph Community Edition (free)
- Google Cloud spot VMs (70% savings)
- Auto-shutdown on inactivity
- Prometheus cost monitoring

### Precision Optimizations  
- GraphRAG community detection
- BRF-specific entity extraction
- Swedish language support
- Hierarchical document summaries
- Hybrid vector + graph retrieval

### Speed Optimizations
- Parallel document processing
- FAISS vector similarity search  
- Memgraph in-memory graph traversals
- Batch embeddings generation
- GPU-accelerated inference

## 🤝 Contributing

This project follows a card-based development approach. Check the current cards and pick up the next available task!

## 📝 License

MIT License - Built with open source love 💖

## 🙏 Acknowledgments

- Microsoft GraphRAG team
- Ollama community  
- Memgraph team
- Swedish BRF community

---

**🔥 Ready to process thousands of BRF documents with GraphRAG precision! 💖**